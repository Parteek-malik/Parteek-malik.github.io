Malik Forge site starter.
Replace placeholder screenshots and downloads with your real files.
Open index.html in a browser or deploy to your hosting.
