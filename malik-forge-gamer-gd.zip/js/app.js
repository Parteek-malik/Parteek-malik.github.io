(function () {
  const root = document.documentElement;
  const progress = document.querySelector(".progress");
  const themeBtn = document.querySelector("[data-theme-toggle]");
  const sidebar = document.querySelector("[data-sidebar]");
  const sidebarBtn = document.querySelector("[data-sidebar-toggle]");
  const year = document.querySelector("[data-year]");
  const search = document.querySelector("[data-search]");
  const filterBtns = document.querySelectorAll("[data-filter]");
  const cards = document.querySelectorAll("[data-card]");
  const galleryMain = document.querySelector("[data-gallery-main]");
  const thumbs = document.querySelectorAll("[data-gallery-thumb]");

  const savedTheme = localStorage.getItem("mf-theme");
  if (savedTheme) root.setAttribute("data-theme", savedTheme);

  if (themeBtn) {
    themeBtn.addEventListener("click", () => {
      const next = root.getAttribute("data-theme") === "light" ? "dark" : "light";
      root.setAttribute("data-theme", next);
      localStorage.setItem("mf-theme", next);
    });
  }

  if (year) year.textContent = new Date().getFullYear();

  const updateProgress = () => {
    if (!progress) return;
    const max = document.body.scrollHeight - window.innerHeight;
    const value = max > 0 ? (window.scrollY / max) * 100 : 0;
    progress.style.width = `${value}%`;
  };

  window.addEventListener("scroll", updateProgress, { passive: true });
  window.addEventListener("resize", updateProgress);
  updateProgress();

  const items = document.querySelectorAll(".fade-in");
  if ("IntersectionObserver" in window && items.length) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });

    items.forEach((el) => observer.observe(el));
  } else {
    items.forEach((el) => el.classList.add("visible"));
  }

  if (sidebarBtn && sidebar) {
    sidebarBtn.addEventListener("click", () => sidebar.classList.toggle("open"));
    document.addEventListener("click", (e) => {
      if (window.innerWidth > 980) return;
      if (!sidebar.contains(e.target) && !sidebarBtn.contains(e.target)) {
        sidebar.classList.remove("open");
      }
    });
  }

  const normalize = (str) => (str || "").toLowerCase().trim();

  if (search && cards.length) {
    const runSearch = () => {
      const q = normalize(search.value);
      cards.forEach((card) => {
        const hay = normalize(card.dataset.title + " " + card.dataset.tags + " " + card.dataset.desc + " " + card.dataset.version);
        card.style.display = hay.includes(q) ? "" : "none";
      });
    };
    search.addEventListener("input", runSearch);
  }

  if (filterBtns.length && cards.length) {
    filterBtns.forEach((btn) => {
      btn.addEventListener("click", () => {
        filterBtns.forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        const filter = btn.dataset.filter;

        cards.forEach((card) => {
          const tags = normalize(card.dataset.tags);
          const match = filter === "all" || tags.includes(filter);
          card.style.display = match ? "" : "none";
        });
      });
    });
  }

  if (galleryMain && thumbs.length) {
    thumbs.forEach((thumb) => {
      thumb.addEventListener("click", () => {
        thumbs.forEach((t) => t.classList.remove("active"));
        thumb.classList.add("active");
        const src = thumb.dataset.full;
        const alt = thumb.querySelector("img")?.alt || "Screenshot";
        galleryMain.innerHTML = `<img src="${src}" alt="${alt}">`;
      });
    });
  }
})();
